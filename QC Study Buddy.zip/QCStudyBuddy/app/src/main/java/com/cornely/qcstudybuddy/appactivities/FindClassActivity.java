package com.cornely.qcstudybuddy.appactivities;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

import com.cornely.qcstudybuddy.R;

public class FindClassActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_find_class);
    }
}